<?php
	$sites = ["Nettuts+", "Psdtuts+", "Mobiletuts+", "Mactuts+"];
	 $k = array_rand($sites);
	echo $sites[$k]."<br/>";


	include "config.php";
	$query = "SELECT * FROM category";
	$result = mysqli_query($con,$query);
	
	$query1 = "SELECT * FROM subcategory";
	$result1 = mysqli_query($con,$query);
	
	
	while($rows = mysqli_fetch_assoc($result)){
				 
				 $CatName = $rows['CatName']; 
				 $CId = $rows['CId']; 


				$category[$CatName] = $rows['CatName']; // Array created here $CatName is used as index and
															// $rows['CatName'] used as array value
			
			

	}
	echo count($category);
	echo "<br>"; 
	$m = array_rand($category);			// array_rand() returns random value from array
	echo $category[$m];
	echo "<br>"; 
	print_r ($category['Dance']);		// print paticular array with index name
	echo "<br>"; 
	
	print_r ($category);				// print whole array with index name

?>