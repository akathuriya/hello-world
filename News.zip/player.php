<?php include "function.php"; ?>
<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Player</title>
  <!-- BOOTSTRAP STYLES-->
    <link href="admin/assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="admin/assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="admin/assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
         <!-- CUSTOM STYLES-->
    <link href="css/style.css" rel="stylesheet" />
	<!-- CUSTOM STYLES-->
    <link href="admin/assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
	.comment{
		margin:10px 0;
		background:#ccc;
		padding:10px;
		border-radius:8px;
		}
  </style>
 </head>
 <body>
<div>
<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="player.php">ABC NEWS</a> 
            </div>
<?php 
	include "config.php";
	$query = "SELECT * FROM category";
	$result = mysqli_query($con,$query);

	$nums = mysqli_num_rows($result);
?>
<div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
	<?PHP	
		if($nums > 0){
			
			

			while($rows = mysqli_fetch_assoc($result)){
				$category = ucwords($rows['CatName']);

				$sub_query = "SELECT * FROM subcategory WHERE CId = '".$rows['CId']."'";
				$result1 = mysqli_query($con,$sub_query);
				$nums1 = mysqli_num_rows($result1);

				
				echo '<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">'.$category.' 
				</a><ul class="dropdown-menu">
					';
						if($nums1 > 0){
						While($rows1 = mysqli_fetch_assoc($result1)){
							$category1 = ucwords($rows1['SCatName']);
							$sub_id = $rows1['SId'];
							echo '<li><a href="player.php?sub-id='.$sub_id.'">'.$category1.'</a></li>';							
							}
					}else{
							echo '<li><a href="#">No Sub Category</a></li>';
						} 
						
					echo'</ul>
							</li>';	
			}

		}else{
			echo "No Category Added";
			}
		
	?>
        
      </ul> 
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#" style="font-size: 16px;">Today : <?php echo date("Y.m.d");?></a></li>
        <li><a href="login.html" class="btn btn-danger ">Sign in</a></li>
      </ul>
    </div>
 </nav></br>

	<?php
		if(isset($_GET['watch'])){
			include "watch.php";
			}
		else{
	?>	
			<div class="container">
				<div class="row">
			
			<?php	
					if(isset($_GET['sub-id'])){
						$SId = $_GET['sub-id'];
						 $vid_query = "SELECT * FROM video WHERE SId= '$SId'";
					}else{
						$vid_query = "SELECT * FROM video";
						}
					
					$vid_result = mysqli_query($con,$vid_query);
				if(mysqli_num_rows($vid_result)>0){
					$i = 1;
					while($v_row = mysqli_fetch_assoc($vid_result)){
			?>
				<div class="col-sm-3">
					<table>
					<tr>
						<td><a href="player.php?watch=<?php echo substr("$v_row[Link]",17);?>">
							<center><img src="admin/<?php echo $v_row['TitleImage'];?>" alt=""  width="100%" height="150"/></center></a>	
						</td>
					</tr>
					<tr>
						<td class="text-info"><a href="player.php?watch=<?php echo substr("$v_row[Link]",17);?>"><b><?php echo substr($v_row['Title'],0,50);?></b></a></td>
					</tr>
					</table><br/>
				</div>
			<?php 
					}
				}else{
					echo "<p class='text-info'>Sorry, No video added. </p>";
					}
			?>
				</div>
			</div>
	<?php
			}
	?>
</div>
 </body>
</html>

