<?php
	function clean($data){
		
		$data = htmlspecialchars($data);
		$data = addslashes($data);
		return $data;
	}
?>