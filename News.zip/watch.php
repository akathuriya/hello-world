 <div class="container">
	<div class="row">
		<?php 
			include "config.php";
			$video_id = $_GET['watch'];
			$str = "https://youtu.be/".$video_id;
			 $v_query = "SELECT * FROM video WHERE Link = '$str'";
			 $result_video = mysqli_query($con,$v_query);
			 $nums = mysqli_num_rows($result_video);
			 if($nums > 0){
				$row_v = mysqli_fetch_assoc($result_video);
				}
			?>
<?php  
		if(isset($_POST['sub-btn'])){
				if(empty($_POST['Email'])|| empty($_POST['Comment'])){
					$err =  "<p class='text-danger'>Fill The Required Feild</p>";
					}else{
						$VId = $row_v['VId'];
						$email = $_POST['Email'];
						$comment = $_POST['Comment'];
						$query = "INSERT INTO comments (VId, UId, Comments, DateTime) values($VId, '$email', '$comment', now())";
						$status = mysqli_query($con, $query);
						
					}
			}

?>
<?php	
		$VId = $row_v['VId'];
		$c_query = "SELECT * FROM comments WHERE VId = $VId AND status ='apporved' ORDER BY Id DESC";
		$c_result = mysqli_query($con, $c_query);
		$c_nums = mysqli_num_rows($c_result);
	?>
		<div class="col-sm-7">
			<iframe src='https://www.youtube.com/embed/<?php if(isset($video_id)){echo $video_id;}
			else{echo "JGwWNGJdvx8";}?>' height="350" width="100%" scrolling="no" frameborder="0" allowfullscreen autoplay></iframe>

			<h4 class="text-muted"><?php echo $row_v['Title'];?></h4>
			<table class="table">
				<tr>
					<td><button class="btn btn-danger square-btn-adjust">Subscribe</button></td>
					<td></td>
					<td></td>
					<td align="right" class="text-muted"><i class="fa fa-thumbs-up fa-lg"> 23k</i>&nbsp&nbsp&nbsp<i class="fa fa-thumbs-down fa-lg"> 1k</i>&nbsp&nbsp&nbsp<i class="fa fa-share fa-lg"> Share</i></td>
					<td></td>	
				</tr>
			</table>
	<?php
		If($c_nums > 0){
				while($c_rows = mysqli_fetch_array($c_result)){
						$comment = $c_rows['Comments'];
						$c_email = $c_rows['UId'];
						echo '<div class="comment">
								<img src="image/find_user.png" align="left" width="100" height="90"/>
								<p>'.$comment.'</br>From: '.$c_email.'</p>
							</div>';
					}
		}else{
			echo "<div><p class='text-info'>No Comment Yet...</p></div>";
			}
	?>
			
				
			<h3>Feedback</h3>
			<?php if(isset($err)){echo $err;}?>
			<?php if(isset($status)){echo "<p class='text-success'>Thank you...We will apporve your comment</p>";}?>
			<form method="post" action="">
				<div class="form-group">
					<label for="Email">Email:</label>
					<input type="text" name="Email" class="form-control">
				</div>
				<div class="form-group">
					<label for="Comment">Comment:</label>
					<textarea name="Comment" class="form-control" cols="40" rows="3">
					</textarea>
				</div>
				<div class="form-group">
					<input type="Submit" name="sub-btn" class="btn btn-danger">
				</div>
			</form>
		</div>
			
		<div class="col-sm-5">
			<?php	
					
					$vid_query = "SELECT * FROM video";
					$vid_result = mysqli_query($con,$vid_query);
				if(mysqli_num_rows($vid_result)>0){
					$i = 1;
					while($v_row = mysqli_fetch_assoc($vid_result)){
			?>
				<a href="player.php?watch=<?php echo substr("$v_row[Link]",17);?>">
					<img src="admin/<?php echo $v_row['TitleImage'];?>" class="img-responsive" alt="" width="150" height="100" align="left" style="margin-right:2%;"/>
				</a>
				<p style="margin-top: 0px;padding-top: 0px;" class="text-info">
					<a href="player.php?watch=<?php echo substr("$v_row[Link]",17);?>"><b><?php echo $v_row['Title'];?></b></a>
					<br/>
					<span class="text-muted">Cricket Video From Sports Section <br/>10M views</span>
				</p><br/>
			<?php 
					}
				}
			?>
		</div>
	</div>
  </div>