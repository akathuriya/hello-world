<?php 
 function clean($data){
	
	$data = htmlspecialchars($data); // for special character
	
	$data = addslashes($data);		// it add slashes before special character

	$data = trim($data);

	return $data;
	}
?>