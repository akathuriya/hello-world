<?php include "config.php"; ?>
<?php
 if(isset($_REQUEST['status']) && $_REQUEST['status'] == 'apporved'){
		 $Id = $_GET['Id'];
		$query1 = "UPDATE comments SET Status = 'apporved' WHERE Id = '$Id';";
			$status = mysqli_query($con,$query1);
			if ($status == '1'){
				header("Location:new-comments.php");
				}
	}
?>

<?php
 if(isset($_REQUEST['status']) && $_REQUEST['status'] == 'pending'){
		 $Id = $_GET['Id'];
		$query1 = "UPDATE comments SET Status = 'pending' WHERE Id = '$Id';";
			$status = mysqli_query($con,$query1);
			if ($status == '1'){
				header("Location:all-comments.php");
				}
	}
?>