<?php include "header.php" ?>
<!-- <div id="page-inner"> -->
		<div class="row">
			<div class="col-md-12">
				<h2>All Category</h2>
			</div>

			</br></br>
		<div class="row">
			<div class="col-md-8">
				<table class="table table-bordered">
				<tr>
					<th>Sr No.</th>
					<th>Sub Category</th>
					<th>Category Name</th>
					<th>Action</th>
				</tr>
			<?php 
				include "config.php";
				$query = "SELECT * FROM subcategory";
				$result = mysqli_query($con,$query);
				if(mysqli_num_rows($result)>0){
					$i = 1;
					while($row = mysqli_fetch_assoc($result)){
						
			?>
				<tr>
					<td><?php echo $i++ ;?></td>
					<td><?php echo $row['SCatName'];?></td>
					<td>
						<?php 
							$query1 = "SELECT CatName FROM category WHERE CId = '".$row['CId']."'";
							$result2 = mysqli_query($con,$query1);
							$row2 = mysqli_fetch_assoc($result2);
							echo ucwords($row2['CatName']);
						?>
					</td>
					<td><a  href="del.php?SId=<?php echo $row['SId'];?>"class='btn btn-danger'>Delete</a></td>
				</tr>
			<?php }
			}else{
				 echo "<p class='text-info'>No Added Category</p>";	
				}?>
				</table>
			</div>
		</div>
</div> <!-- end of inner-page -->
<?php include "footer.php"; ?>
