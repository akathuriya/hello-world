<?php
$con = mysqli_connect("localhost","root");
	if(!$con){
			die("Connection Error: Not Connected with Database");
			}
			else{echo "";}

	mysqli_select_db($con,"news");
?>