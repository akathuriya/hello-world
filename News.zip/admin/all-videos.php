<?php include "header.php" ?>
<!-- <div id="page-inner"> -->
		<div class="row">
			<div class="col-md-12">
				<h2>All Category</h2>
			</div>

			</br></br>
		<div class="row">
			<div class="col-md-8">
				<table class="table table-bordered">
				<tr>
					<th>Sr No.</th>
					<th>Video Title</th>
					<th>Title Image</th>
					<th>Sub Category</th>
					<th>Action</th>
				</tr>
			<?php 
				include "config.php";
				$query = "SELECT * FROM video";
				$result = mysqli_query($con,$query);
				if(mysqli_num_rows($result)>0){
					$i = 1;
					while($row = mysqli_fetch_assoc($result)){
						
			?>
				<tr>
					<td><?php echo $i++ ;?></td>
					<td><?php echo $row['Title'];?></td>
					<td><center><img src="<?php echo $row['TitleImage'];?>" alt="" class="img-responsive" width="100" height="100"/></center></td>
					<td>
						<?php 
							$query1 = "SELECT SCatName FROM subcategory WHERE SId = '".$row['SId']."'";
							$result2 = mysqli_query($con,$query1);
							$row2 = mysqli_fetch_assoc($result2);
							echo ucwords($row2['SCatName']);
						?>
					</td>
					<td><a  href="del.php?VId=<?php echo $row['VId'];?>"class='btn btn-danger'>Delete</a></td>
				</tr>
			<?php }
			}else{
				 echo "<p class='text-info'>No Added Category</p>";	
				}?>
				</table>
			</div>
		</div>
</div> <!-- end of inner-page -->
<?php include "footer.php"; ?>
