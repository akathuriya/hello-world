<?php include "header.php" ?>
<!-- <div id="page-inner"> -->
		<div class="row">
			<div class="col-md-12">
				<h2>All Category</h2>
			</div>

			</br></br>
		<div class="row">
			<div class="col-md-11">
				<table class="table table-bordered">
				<tr>
					<th>Sr No.</th>
					<th>Comment</th>
					<th>User Id</th>
					<th>Video Id</th>
					<th>Status</th>
					<th>Video</th>
					<th>Action</th>
				</tr>
			<?php 
				include "config.php";
				$query = "SELECT * FROM comments Where status = 'apporved'";
				$result = mysqli_query($con,$query);
				if(mysqli_num_rows($result)>0){
					$i = 1;
					while($row = mysqli_fetch_assoc($result)){			
			?>
				<tr>
					<td><?php echo $i++ ;?></td>
					<td><?php echo $row['Comments'];?></td>
					<td><?php echo $row['UId'];?></td>
					<td><?php echo $row['VId'];?></td>
					<td><?php echo $row['Status'];?></td>
					<td>
						<?php 
							$query1 = "SELECT TitleImage FROM video WHERE VId = '".$row['VId']."'";
							$result2 = mysqli_query($con,$query1);
							$row2 = mysqli_fetch_assoc($result2);
						?>
						<center><img src="<?php echo $row2['TitleImage'];?>" alt="" class="img-responsive" width="100" height="100"/></center>
					</td>
					<td><a href="comment-status.php?status=pending&&Id=<?php echo $row['Id'];?>"class='btn btn-warning'>Pending</a>&nbsp
						<a href="del.php?Id=<?php echo $row['Id'];?>&&page=all-c"class='btn btn-danger'>Delete</a>
					</td>
				</tr>
			<?php }
			}else{
				 echo "<p class='text-info'>No comments Yet</p>";	
				}?>
				</table>
			</div>
		</div>
</div> <!-- end of inner-page -->
<?php include "footer.php"; ?>
