<?php include "header.php" ?>
<!-- <div id="page-inner"> -->
		<div class="row">
			<div class="col-md-12">
				<h2>Add New Video</h2>
			</div>

			</br></br>
		<div class="row">
			<div class="col-md-8">
<?php 
	if(isset($_POST['btn'])){
		if($_FILES['Image']['size']>0){

	
					$file_tmp = $_FILES['Image']['tmp_name'];
					$file_name = $_FILES['Image']['name'];
					$target_dir = "upload/";
					$target_file = $target_dir.BASENAME($_FILES['Image']['name']);
					$uploadOk = 1;
					$imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
					
					
	
					if(empty($_POST['Title']) || empty($_POST['Description']) || empty($_POST['Link'])) {
						$err= "<p class='text-danger'>Fill Required Category Field</p>";
					}else{
						move_uploaded_file($file_tmp,"upload/".$file_name);
						 $SId=  $_POST['SId'];
						$Title = clean($_POST['Title']);

						 $Description = clean($_POST['Description']);
						$Link = $_POST['Link'];
						include "config.php";

						$query = "INSERT INTO video (SId, Title, TitleImage, Description, Link, DateTime) values (".$SId.", '$Title', '$target_file', '$Description', '$Link', now())";
						$status = mysqli_query($con,$query);

						
						}
				
			
		}
	else{					
		echo "<p class='text-danger'>Image is Compulsory</p>";
		}//btn-if-else
	}
?>
<?php if(isset($err)){echo $err;}?>
<?php if(isset($status) && $status=='1'){echo "<p class='text-success'>Thank you, Your Record have been Successfully Submited</p>";}?>
				<form action="" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label>Video Title</label>
						<input type="text" class="form-control" name="Title"/>
					</div>
					<div class="form-group">
						<label>Title Image</label>
						<input type="file" class="form-control" name="Image"/>
					</div>
					<div class="form-group">
						<label>Description</label>
						<textarea  class="form-control" name="Description" rows="4" cols="50">
						</textarea>
					</div>
					<div class="form-group">
						<label>Video Link</label>
						<input type="text" class="form-control" name="Link"/>
					</div>
		
					<div class="form-group">
						<label>Video Catergory</label>
						<select class="form-control" name="SId">
							<option value="">-Select-</option>
						<?php 
							include "config.php";
							$query = "SELECT * FROM subcategory";
							$result2 = mysqli_query($con,$query);
							if(mysqli_num_rows($result2)>0){
								$i = 1;
							while($row = mysqli_fetch_assoc($result2)){
						?>	
							<option value="<?php echo $row['SId'];?>"><?php echo $row['SCatName'];?></option>
						<?php
							}
						}
						?>
							
						</select>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-default" value="Add Video" name="btn"/>
					</div>

				</form>
			</div>
		</div>
</div> <!-- end of inner-page -->
<?php include "footer.php"; ?>
