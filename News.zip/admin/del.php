<?php include "config.php";?>
<?php
	If(isset($_REQUEST['SId'])){
		$SId = $_REQUEST['SId'];
		$sub_query = "DELETE FROM subcategory WHERE SId = '$SId'";
		$status = mysqli_query($con,$sub_query);
			if ($status == '1'){
				header('Location: http://localhost/News/admin/all-subcategory.php');
			}else{
				echo "Error in Deletation of Record";
				}
		}
?>
<?php
	If(isset($_REQUEST['Id'])){
		echo $page = $_GET['page'];
		echo $Id = $_REQUEST['Id'];
		echo $sub_query = "DELETE FROM comments WHERE Id = '$Id'";
		$status = mysqli_query($con,$sub_query);
			if ($status == '1'){
				if($page == 'nc'){
					header("Location:new-comments.php");
					}else{
						header("Location:all-comments.php");
					}
				}else{
					echo "Error in Deletation of Record";
				}
		}
?>