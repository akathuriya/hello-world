<?php include "header.php" ?>
<!-- <div id="page-inner"> -->
		<div class="row">
			<div class="col-md-12">
				<h2>Add New Category</h2>
			</div>

			</br></br>
		<div class="row">
			<div class="col-md-8">
<?php 
	if(isset($_POST['btn'])){
		if(empty($_POST['Category'])){
			$err= "<p class='text-danger'>Fill Required Category Field</p>";
			}else{
				$category = clean($_POST['Category']);
				include "config.php";

				$query = "INSERT INTO category (CatName) values ('$category')";
				$status = mysqli_query($con,$query);
				}
		}
?>
				<form action="" method="post">
					<div class="form-group">
						<label>Category</label>
						<?php if(isset($err)){echo $err;}?>
						<?php if(isset($status)){
								echo "<p class='text-success'>Thank you, Your Record have been Successfully Submited</p>";}
						?>
						<input type="text" class="form-control" name="Category"/>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-default" value="Add Category" name="btn"/>
					</div>
				</form>
			</div>
		</div>
</div> <!-- end of inner-page -->
<?php include "footer.php"; ?>
